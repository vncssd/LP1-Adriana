-- ============================================================
--  LojáFX  –  Schema PostgreSQL
-- ============================================================

-- Banco de dados:  lojafx
-- Criação: psql -U postgres -c "CREATE DATABASE lojafx;"
--          psql -U postgres -d lojafx -f schema.sql

-- ============================================================
--  LOJA
-- ============================================================

CREATE TABLE IF NOT EXISTS produto (
    id                   SERIAL       PRIMARY KEY,
    nome                 VARCHAR(150) NOT NULL,
    preco                NUMERIC(10,2) NOT NULL CHECK (preco >= 0),
    quantidade_em_estoque INTEGER      NOT NULL DEFAULT 0 CHECK (quantidade_em_estoque >= 0),
    quantidade_vendida    INTEGER      NOT NULL DEFAULT 0 CHECK (quantidade_vendida >= 0)
);

-- ============================================================
--  FEIRA
-- ============================================================

CREATE TABLE IF NOT EXISTS barraca (
    id                  SERIAL  PRIMARY KEY,
    esta_aberta         BOOLEAN NOT NULL DEFAULT FALSE,
    horas_de_expediente INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS funcionario (
    id                        SERIAL       PRIMARY KEY,
    barraca_id                INTEGER      NOT NULL REFERENCES barraca(id) ON DELETE CASCADE,
    nome                      VARCHAR(150) NOT NULL,
    salario_por_hora           NUMERIC(10,2) NOT NULL CHECK (salario_por_hora >= 0),
    horas_trabalhadas_semana   INTEGER      NOT NULL DEFAULT 0 CHECK (horas_trabalhadas_semana >= 0)
);

-- ============================================================
--  BARBEARIA
-- ============================================================

CREATE TABLE IF NOT EXISTS barbearia (
    id                              SERIAL  PRIMARY KEY,
    esta_aberta                     BOOLEAN NOT NULL DEFAULT FALSE,
    possui_equipamentos_sem_manutencao BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE TABLE IF NOT EXISTS equipamento (
    id                  SERIAL       PRIMARY KEY,
    barbearia_id        INTEGER      NOT NULL REFERENCES barbearia(id) ON DELETE CASCADE,
    marca               VARCHAR(100) NOT NULL,
    modelo              VARCHAR(100) NOT NULL,
    recebeu_manutencao  BOOLEAN      NOT NULL DEFAULT TRUE,
    estado              VARCHAR(20)  NOT NULL DEFAULT 'DESLIGADO'
                            CHECK (estado IN ('LIGADO','DESLIGADO'))
);
